# TODO: Gestión de Puertos y Redespliegue

## Tareas a completar:
- [x] 1. Identificar procesos corriendo en puertos 5000, 5001 y 5002
- [x] 2. Detener procesos en puerto 5000
- [x] 3. Detener procesos en puerto 5001  
- [x] 4. Detener procesos en puerto 5002
- [x] 5. Verificar que los puertos estén libres
- [x] 6. Identificar el proyecto/aplicación a redesplegar
- [x] 7. Redesplegar la aplicación en puerto 5000
- [x] 8. Verificar que el redespliegue sea exitoso

## Notas:
- Fecha: 2025-10-17
- Puertos objetivo: 5000, 5001, 5002
- Puerto de redespliegue: 5000
